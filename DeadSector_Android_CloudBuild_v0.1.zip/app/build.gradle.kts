plugins {
    id("com.android.application")
}

android {
    namespace = "com.deadsector.game"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.deadsector.game"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1"
    }
}

dependencies {
}