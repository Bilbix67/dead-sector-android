package com.deadsector.game;

import android.content.Context;
import android.graphics.*;
import android.view.*;
import java.util.*;

public class GameView extends View {

    static class Zombie {
        float x, y, hp, maxHp, speed, r;
        Zombie(float x, float y, float hp, float speed, float r) {
            this.x=x; this.y=y; this.hp=hp; this.maxHp=hp; this.speed=speed; this.r=r;
        }
    }

    static class Bullet {
        float x, y, vx, vy, damage;
        Bullet(float x,float y,float vx,float vy,float damage){
            this.x=x; this.y=y; this.vx=vx; this.vy=vy; this.damage=damage;
        }
    }

    static class Reward {
        String name, desc;
        int kind;
        float amount;
        Reward(String n,String d,int k,float a){ name=n; desc=d; kind=k; amount=a; }
    }

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Random rng = new Random();
    private final ArrayList<Zombie> zombies = new ArrayList<>();
    private final ArrayList<Bullet> bullets = new ArrayList<>();

    private float px, py, pr = 28f;
    private float hp = 100, maxHp = 100;
    private float moveSpeed = 340f;
    private float damage = 22f;
    private float fireRate = 3.4f;
    private float bulletSpeed = 760f;
    private float critChance = 0.08f;
    private float lastShot = 0;

    private int wave = 1, credits = 0, kills = 0;
    private int remainingToSpawn = 0;
    private float spawnTimer = 0;
    private boolean betweenWaves = false;
    private boolean gameOver = false;
    private long lastNs = System.nanoTime();

    // virtual joystick
    private boolean moveTouch = false;
    private int movePointer = -1;
    private float joyBaseX, joyBaseY, joyX, joyY;
    private float joyRadius = 110f;

    private Reward[] rewards = new Reward[3];

    public GameView(Context c) {
        super(c);
        setFocusable(true);
        setBackgroundColor(Color.rgb(12,16,18));
    }

    @Override protected void onSizeChanged(int w,int h,int oldw,int oldh) {
        px = w*0.5f; py = h*0.52f;
        joyBaseX = 150; joyBaseY = h-150;
        joyX = joyBaseX; joyY = joyBaseY;
        startWave();
    }

    private void startWave() {
        zombies.clear();
        bullets.clear();
        betweenWaves = false;
        remainingToSpawn = 6 + wave*3;
        spawnTimer = 0.2f;
        hp = Math.min(maxHp, hp + maxHp*0.18f);
    }

    private Zombie nearestZombie() {
        Zombie best=null;
        float bd=Float.MAX_VALUE;
        for(Zombie z: zombies){
            float dx=z.x-px, dy=z.y-py;
            float d=dx*dx+dy*dy;
            if(d<bd){bd=d;best=z;}
        }
        return best;
    }

    private void spawnZombie() {
        float w=getWidth(), h=getHeight();
        int side=rng.nextInt(4);
        float x,y;
        if(side==0){x=-40;y=rng.nextFloat()*h;}
        else if(side==1){x=w+40;y=rng.nextFloat()*h;}
        else if(side==2){x=rng.nextFloat()*w;y=-40;}
        else {x=rng.nextFloat()*w;y=h+40;}
        float hpz = 44f * (1f + (wave-1)*0.16f);
        float spd = 78f * (1f + (wave-1)*0.025f);
        float r = 24f;
        if(wave%10==0 && remainingToSpawn==1){
            hpz *= 8f; spd*=0.82f; r=52f;
        } else if(wave>=5 && rng.nextFloat()<0.18f){
            spd*=1.85f; hpz*=0.72f; r=20f;
        } else if(wave>=8 && rng.nextFloat()<0.12f){
            hpz*=2.6f; spd*=0.72f; r=31f;
        }
        zombies.add(new Zombie(x,y,hpz,spd,r));
    }

    private Reward randReward() {
        int tier = wave>=20?3:wave>=10?2:wave>=5?1:0;
        int k=rng.nextInt(6);
        float scale=1f+tier*0.25f;
        switch(k){
            case 0: return new Reward("Puissance", "+"+(int)(12*scale)+"% dégâts",0,0.12f*scale);
            case 1: return new Reward("Cadence", "+"+(int)(10*scale)+"% vitesse de tir",1,0.10f*scale);
            case 2: return new Reward("Blindage", "+"+(int)(20*scale)+" PV max",2,20f*scale);
            case 3: return new Reward("Mobilité", "+"+(int)(8*scale)+"% vitesse",3,0.08f*scale);
            case 4: return new Reward("Précision", "+"+(int)(5*scale)+"% critique",4,0.05f*scale);
            default:return new Reward("Prime", "+"+(int)(120*scale)+" crédits",5,120f*scale);
        }
    }

    private void prepareRewards() {
        rewards[0]=randReward(); rewards[1]=randReward(); rewards[2]=randReward();
    }

    private void chooseReward(int i) {
        Reward r=rewards[i];
        if(r.kind==0) damage*=1f+r.amount;
        if(r.kind==1) fireRate*=1f+r.amount;
        if(r.kind==2){maxHp+=r.amount; hp=Math.min(maxHp,hp+r.amount);}
        if(r.kind==3) moveSpeed*=1f+r.amount;
        if(r.kind==4) critChance=Math.min(0.55f,critChance+r.amount);
        if(r.kind==5) credits+=(int)r.amount;
        wave++;
        startWave();
    }

    private void restart() {
        hp=maxHp=100; moveSpeed=340; damage=22; fireRate=3.4f; bulletSpeed=760; critChance=.08f;
        wave=1; credits=0; kills=0; gameOver=false;
        px=getWidth()/2f; py=getHeight()/2f;
        startWave();
    }

    private void update(float dt) {
        if(gameOver || betweenWaves) return;

        // movement
        if(moveTouch){
            float dx=joyX-joyBaseX, dy=joyY-joyBaseY;
            float len=(float)Math.sqrt(dx*dx+dy*dy);
            if(len>1){
                dx/=Math.max(len,joyRadius); dy/=Math.max(len,joyRadius);
                px += dx*moveSpeed*dt;
                py += dy*moveSpeed*dt;
            }
        }
        px=Math.max(pr,Math.min(getWidth()-pr,px));
        py=Math.max(pr,Math.min(getHeight()-pr,py));

        // spawn
        spawnTimer-=dt;
        if(remainingToSpawn>0 && spawnTimer<=0){
            spawnZombie(); remainingToSpawn--;
            spawnTimer = Math.max(0.24f, 0.72f-wave*0.012f);
        }

        // auto shoot
        lastShot += dt;
        Zombie nz=nearestZombie();
        if(nz!=null && lastShot >= 1f/fireRate){
            float dx=nz.x-px, dy=nz.y-py, len=(float)Math.sqrt(dx*dx+dy*dy);
            if(len>0){
                dx/=len; dy/=len;
                float d=damage;
                if(rng.nextFloat()<critChance) d*=2f;
                bullets.add(new Bullet(px,py,dx*bulletSpeed,dy*bulletSpeed,d));
                lastShot=0;
            }
        }

        // bullets
        for(int i=bullets.size()-1;i>=0;i--){
            Bullet b=bullets.get(i);
            b.x+=b.vx*dt; b.y+=b.vy*dt;
            boolean remove = b.x<-50||b.y<-50||b.x>getWidth()+50||b.y>getHeight()+50;
            if(!remove){
                for(int j=zombies.size()-1;j>=0;j--){
                    Zombie z=zombies.get(j);
                    float dx=b.x-z.x,dy=b.y-z.y;
                    if(dx*dx+dy*dy < (z.r+7)*(z.r+7)){
                        z.hp-=b.damage; remove=true;
                        if(z.hp<=0){
                            credits += 10 + wave;
                            kills++;
                            zombies.remove(j);
                        }
                        break;
                    }
                }
            }
            if(remove) bullets.remove(i);
        }

        // zombies
        for(Zombie z: zombies){
            float dx=px-z.x,dy=py-z.y, len=(float)Math.sqrt(dx*dx+dy*dy);
            if(len>0){z.x+=dx/len*z.speed*dt;z.y+=dy/len*z.speed*dt;}
            if(len<z.r+pr){
                hp -= (12f + wave*0.7f)*dt;
            }
        }

        if(hp<=0){hp=0;gameOver=true;}
        if(remainingToSpawn==0 && zombies.isEmpty()){
            betweenWaves=true;
            credits += 60 + wave*20;
            prepareRewards();
        }
    }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        long now=System.nanoTime();
        float dt=Math.min(0.033f,(now-lastNs)/1_000_000_000f);
        lastNs=now;
        update(dt);

        // background grid
        p.setStrokeWidth(1);
        p.setColor(Color.rgb(24,31,34));
        for(int x=0;x<getWidth();x+=80)c.drawLine(x,0,x,getHeight(),p);
        for(int y=0;y<getHeight();y+=80)c.drawLine(0,y,getWidth(),y,p);

        // bullets
        p.setColor(Color.YELLOW);
        for(Bullet b:bullets)c.drawCircle(b.x,b.y,6,p);

        // zombies
        for(Zombie z:zombies){
            p.setColor(z.r>45?Color.rgb(155,35,35):Color.rgb(76,130,72));
            c.drawCircle(z.x,z.y,z.r,p);
            p.setColor(Color.DKGRAY);
            c.drawRect(z.x-z.r,z.y-z.r-12,z.x+z.r,z.y-z.r-7,p);
            p.setColor(Color.RED);
            c.drawRect(z.x-z.r,z.y-z.r-12,z.x-z.r+2*z.r*(z.hp/z.maxHp),z.y-z.r-7,p);
        }

        // player
        p.setColor(Color.rgb(75,150,220));
        c.drawCircle(px,py,pr,p);
        p.setColor(Color.WHITE);
        c.drawCircle(px+8,py-6,6,p);

        // joystick
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(5); p.setColor(Color.argb(150,255,255,255));
        c.drawCircle(joyBaseX,joyBaseY,joyRadius,p);
        p.setStyle(Paint.Style.FILL); p.setColor(Color.argb(160,255,255,255));
        c.drawCircle(joyX,joyY,42,p);

        // HUD
        p.setTextSize(34); p.setColor(Color.WHITE);
        c.drawText("MANCHE "+wave,24,42,p);
        c.drawText("Crédits "+credits,24,82,p);
        c.drawText("Kills "+kills,24,122,p);
        c.drawText("Dégâts "+(int)damage,24,162,p);

        // HP bar
        float bw=320,bh=25,bx=getWidth()-bw-30,by=30;
        p.setColor(Color.DKGRAY);c.drawRect(bx,by,bx+bw,by+bh,p);
        p.setColor(Color.rgb(210,50,55));c.drawRect(bx,by,bx+bw*(hp/maxHp),by+bh,p);
        p.setColor(Color.WHITE);p.setTextSize(24);c.drawText((int)hp+" / "+(int)maxHp+" PV",bx,by+52,p);

        if(betweenWaves){
            p.setColor(Color.argb(220,0,0,0));c.drawRect(0,0,getWidth(),getHeight(),p);
            p.setColor(Color.WHITE);p.setTextAlign(Paint.Align.CENTER);p.setTextSize(46);
            c.drawText("MANCHE "+wave+" TERMINÉE",getWidth()/2f,100,p);
            p.setTextSize(26);
            c.drawText("Choisis une récompense",getWidth()/2f,145,p);

            float cardW=(getWidth()-120)/3f;
            for(int i=0;i<3;i++){
                float x=30+i*(cardW+30), y=190;
                p.setColor(Color.rgb(32,40,44));c.drawRoundRect(x,y,x+cardW,y+210,24,24,p);
                p.setColor(Color.WHITE);p.setTextSize(30);
                c.drawText(rewards[i].name,x+cardW/2f,y+65,p);
                p.setTextSize(22);
                c.drawText(rewards[i].desc,x+cardW/2f,y+115,p);
                p.setTextSize(18);
                c.drawText("TOUCHE POUR CHOISIR",x+cardW/2f,y+175,p);
            }
            p.setTextAlign(Paint.Align.LEFT);
        }

        if(gameOver){
            p.setColor(Color.argb(230,0,0,0));c.drawRect(0,0,getWidth(),getHeight(),p);
            p.setColor(Color.WHITE);p.setTextAlign(Paint.Align.CENTER);p.setTextSize(56);
            c.drawText("MORT",getWidth()/2f,getHeight()/2f-50,p);
            p.setTextSize(30);
            c.drawText("Manche atteinte : "+wave,getWidth()/2f,getHeight()/2f+10,p);
            c.drawText("Touchez l'écran pour recommencer",getWidth()/2f,getHeight()/2f+65,p);
            p.setTextAlign(Paint.Align.LEFT);
        }

        postInvalidateOnAnimation();
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        if(gameOver && e.getActionMasked()==MotionEvent.ACTION_DOWN){
            restart(); return true;
        }
        if(betweenWaves && e.getActionMasked()==MotionEvent.ACTION_DOWN){
            float cardW=(getWidth()-120)/3f;
            float y=e.getY();
            if(y>=190 && y<=400){
                for(int i=0;i<3;i++){
                    float x=30+i*(cardW+30);
                    if(e.getX()>=x && e.getX()<=x+cardW){ chooseReward(i); return true; }
                }
            }
        }

        int action=e.getActionMasked();
        int idx=e.getActionIndex();
        int pid=e.getPointerId(idx);

        if(action==MotionEvent.ACTION_DOWN || action==MotionEvent.ACTION_POINTER_DOWN){
            float x=e.getX(idx), y=e.getY(idx);
            if(x<getWidth()*0.5f && !moveTouch){
                moveTouch=true; movePointer=pid;
                joyBaseX=x; joyBaseY=y; joyX=x; joyY=y;
            }
        } else if(action==MotionEvent.ACTION_MOVE){
            for(int i=0;i<e.getPointerCount();i++){
                if(e.getPointerId(i)==movePointer){
                    float x=e.getX(i), y=e.getY(i);
                    float dx=x-joyBaseX,dy=y-joyBaseY,len=(float)Math.sqrt(dx*dx+dy*dy);
                    if(len>joyRadius){dx=dx/len*joyRadius;dy=dy/len*joyRadius;}
                    joyX=joyBaseX+dx; joyY=joyBaseY+dy;
                }
            }
        } else if(action==MotionEvent.ACTION_UP || action==MotionEvent.ACTION_POINTER_UP || action==MotionEvent.ACTION_CANCEL){
            if(pid==movePointer || action==MotionEvent.ACTION_CANCEL){
                moveTouch=false; movePointer=-1; joyX=joyBaseX; joyY=joyBaseY;
            }
        }
        return true;
    }
}