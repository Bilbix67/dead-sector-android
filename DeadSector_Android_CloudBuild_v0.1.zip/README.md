# Dead Sector Android

Prototype mobile Android vue du dessus.

## Contenu de la V0.1
- Manches infinies
- Zombies de plus en plus puissants
- Sprinteurs / tanks / boss
- Tir automatique vers le zombie le plus proche
- Joystick tactile
- Crédits et kills
- Récompense au choix entre 3 à la fin de chaque manche
- Progression : dégâts, cadence, PV, vitesse, critique
- Boss toutes les 10 manches

## APK dans GitHub
1. Ouvrir l'onglet **Actions**
2. Ouvrir **Build Android APK**
3. Lancer **Run workflow** si nécessaire
4. Quand le build est vert, ouvrir le run
5. Télécharger l'artifact **DeadSector-APK**
6. Décompresser le ZIP téléchargé puis installer `app-debug.apk`